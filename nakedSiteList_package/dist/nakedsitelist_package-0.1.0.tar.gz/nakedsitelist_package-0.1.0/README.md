# Naked Site List Package

A package with functions for determining towers with no active or planned tenants, called "Naked Sites". Naked Sites should be prioritized in leasing out or decommissioning. 

## Installation

```bash

pip install nakedSiteList_package